// Import required modules
const express = require('express');
const bodyParser = require('body-parser');

// Initialize the Express app
const app = express();
const port = 3000;

// Middleware to serve static files and parse form data
app.use(express.static('public')); // Serve static files (HTML, CSS, JS) from 'public'
app.use(bodyParser.urlencoded({ extended: true })); // Parse form data

// GET route for the HTML form
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// POST route for BMI calculation
app.post('/calculate-bmi', (req, res) => {
    const { weight, height } = req.body;

    // Validate inputs
    if (!weight || !height || weight <= 0 || height <= 0) {
        return res.send(`
            <h1>Invalid Input</h1>
            <p>Please ensure both weight and height are positive numbers.</p>
            <a href="/">Go Back</a>
        `);
    }

    // Calculate BMI
    const bmi = weight / (height * height);
    let category = '';
    let color = '';

    // Determine BMI category and color
    if (bmi < 18.5) {
        category = 'Underweight';
        color = 'blue';
    } else if (bmi < 24.9) {
        category = 'Normal weight';
        color = 'green';
    } else if (bmi < 29.9) {
        category = 'Overweight';
        color = 'yellow';
    } else {
        category = 'Obese';
        color = 'red';
    }

    // Respond with the BMI result
    res.send(`
        <style>
            body {
                font-family: Arial, sans-serif;
                text-align: center;
                margin-top: 50px;
            }
            .result {
                color: ${color};
                font-size: 24px;
                font-weight: bold;
            }
        </style>
        <h1>Your BMI Result</h1>
        <p class="result">BMI: ${bmi.toFixed(2)}</p>
        <p class="result">Category: ${category}</p>
        <a href="/">Go Back</a>
    `);
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
